/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.snake;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.TextView;

/**
 * The purpose of this project is to add THREE new features to an application that we choose.
 *
 * <h1>Snake</h1>
 * Snake is an implementation of the classic game snake in which a player controls a serpent roaming
 * around the garden looking for apple. Anytime the snake gets to an apple, it grows in length and
 * its moving speed increases. So the trick is to be able handle this roaming long and speedy snake
 * in such a way that it won’t run into itself or into the garden wall.
 *
 * <b>THREE NEW FEATURES</b>
 *     1. Level option
 *     2. Displays high score
 *     3. Implements beginner level
 *     (EXTRA FEATURE to make this game more user friendly)
 *
 * <p>
 * 1. Level option <br/>
 *     Adding the option to choose two different levels from the welcome screen of the game:
 *     Beginner Level and Advanced Level.
 *     In addition to the welcome screen, anytime the game ends, the user will have the option the
 *     change the level before the beginning of a new round. The implementation of the advance level
 *     should be the one provided by the sample as it is without any change. So when the user
 *     selects the option Advanced level, the snake will be roaming from apple to apple while
 *     increasing its length and gaining more speed.
 * </p>
 *
 * <p>
 * 2. Displays high score <br/>
 *     This functionality will offer the option to store the highest game score until the player
 *     decides to reset the counter. So this functionality will be implemented at the end of the
 *     game, so the score of the player get to be compared to the previous highest score. In case
 *     the score of the present game is higher than the score previously stored as being the
 *     highest, then the highest score should become the actual score. At the same time if the
 *     previous highest score was different from zero, we will display the message “Congratulation!!
 *     You just set a new Record”, followed by a message displaying the new highest score.
 * </p>
 *
 * <p>
 * 3. Implements beginner level <br/>
 *     In this level, the game will offer some pink apple that will show up on the screen anytime
 *     the snake speed get to a certain threshold defined by the programmer. Whenever the snake
 *     reaches the blue apple, its speed should be reset to the initial speed at which it was moving
 *     in the beginning of the game.
 * </p>
 *
 * In addition to these three new features, I added another new feature to allow user to see the
 * current score while playing the game.
 *
 * <b>NOTE: </b> The added or modified variables and methods are denoted and documented by the block comments
 * throughout the code.
 *
 * @author Zhuoying Cai
 * @since 12-08-2017
 */

public class Snake extends Activity{

    /**
     * Constants for desired direction of moving the snake
     */
    public static int MOVE_LEFT = 0;
    public static int MOVE_UP = 1;
    public static int MOVE_DOWN = 2;
    public static int MOVE_RIGHT = 3;

    private static String ICICLE_KEY = "snake-view";

    private SnakeView mSnakeView;

    /* NEW */
    protected static AlertDialog recordBuilder;
    protected static AlertDialog wonBuilder;
    protected static SharedPreferences settings;
    protected static SharedPreferences.Editor editor;

    /**
     * Called when Activity is first created. Turns off the title bar, sets up the content views,
     * and fires up the SnakeView.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.snake_layout);

        mSnakeView = (SnakeView) findViewById(R.id.snake);
        mSnakeView.setDependentViews((TextView) findViewById(R.id.text),
                findViewById(R.id.arrowContainer), findViewById(R.id.background),
                findViewById(R.id.beginnerButton), findViewById(R.id.advancedButton),
                (TextView) findViewById(R.id.scoreLabel),
                (TextView) findViewById(R.id.highScoreLabel), findViewById(R.id.resetButton),
                (TextView) findViewById(R.id.showScore));

        if (savedInstanceState == null) {
            // We were just launched -- set up a new game
            mSnakeView.setMode(SnakeView.READY);
        } else {
            // We are being restored
            Bundle map = savedInstanceState.getBundle(ICICLE_KEY);
            if (map != null) {
                mSnakeView.restoreState(map);
            } else {
                mSnakeView.setMode(SnakeView.PAUSE);
            }
        }

        /* Registers beginner level button to start a new game */
        Button mBeginnerButton = (Button) findViewById(R.id.beginnerButton);
        mBeginnerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mSnakeView.setLvl(false);
                mSnakeView.moveSnake(MOVE_UP);
            }
        });

        /* Registers advanced level button to start a new game */
        Button mAdvancedButton = (Button) findViewById(R.id.advancedButton);
        mAdvancedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mSnakeView.setLvl(true);
                mSnakeView.moveSnake(MOVE_UP);
            }
        });

        mSnakeView.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (mSnakeView.getGameState() == SnakeView.RUNNING) {
                    // Normalize x,y between 0 and 1
                    float x = event.getX() / v.getWidth();
                    float y = event.getY() / v.getHeight();

                    // Direction will be [0,1,2,3] depending on quadrant
                    int direction = 0;
                    direction = (x > y) ? 1 : 0;
                    direction |= (x > 1 - y) ? 2 : 0;

                    // Direction is same as the quadrant which was clicked
                    mSnakeView.moveSnake(direction);

                } else {
                    // If the game is not running then on touching any part of the screen
                    // we start the game by sending MOVE_UP signal to SnakeView
                    mSnakeView.moveSnake(MOVE_UP);
                }

                return false;
            }
        });

        /* Show congrats dialog box if the user creates a new high score */
        recordBuilder = new AlertDialog.Builder(Snake.this).create();
        recordBuilder.setTitle("Congratulation!!");
        recordBuilder.setMessage("You just set a new record!!");
        recordBuilder.setButton(AlertDialog.BUTTON_NEUTRAL, "Ok",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });

        /* Show congrats dialog box if the user won the game */
        wonBuilder = new AlertDialog.Builder(Snake.this).create();
        wonBuilder.setTitle("Congratulation!!");
        wonBuilder.setMessage("You won the game!!");
        wonBuilder.setButton(AlertDialog.BUTTON_NEUTRAL, "Ok",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });

        /*
         * Set up getSharedPreferences to store high score data. This allows the application
         * to retrieve the high score from the system even if the user close/kill the game.
         */
        settings = getSharedPreferences("GAME_DATA", Context.MODE_PRIVATE);
        /* Retrieves the high score that is stored in the system */
        SnakeView.highScore = settings.getLong("HIGH_SCORE", 0);

        /* Register reset high score button */
        Button mResetButton = (Button) findViewById(R.id.resetButton);
        mResetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*
                 * Ask from conformation
                 * Makes sure that the user did not click this button by accident
                 */
                AlertDialog conformation = new AlertDialog.Builder(Snake.this).create();
                conformation.setMessage("Are you sure?");

                /* If YES button is clicked */
                conformation.setButton(AlertDialog.BUTTON_POSITIVE, "Yes",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                SnakeView.highScore = 0;

                                /* Set the high score to 0 */
                                Snake.editor = Snake.settings.edit();
                                Snake.editor.putLong("HIGH_SCORE", 0);
                                Snake.editor.commit();
                            }
                        });

                /* If NO button is clicked */
                conformation.setButton(AlertDialog.BUTTON_NEGATIVE, "No",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        });

                conformation.show();
            }
        });
    }


    @Override
    protected void onPause() {
        super.onPause();
        // Pause the game along with the activity
        mSnakeView.setMode(SnakeView.PAUSE);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        // Store the game state
        outState.putBundle(ICICLE_KEY, mSnakeView.saveState());
    }

    /**
     * Handles key events in the game. Update the direction our snake is traveling based on the
     * DPAD.
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent msg) {

        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP:
                mSnakeView.moveSnake(MOVE_UP);
                break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                mSnakeView.moveSnake(MOVE_RIGHT);
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                mSnakeView.moveSnake(MOVE_DOWN);
                break;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                mSnakeView.moveSnake(MOVE_LEFT);
                break;
        }

        return super.onKeyDown(keyCode, msg);
    }

}

